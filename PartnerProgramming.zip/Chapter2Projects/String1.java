
/**
 * Write a description of class String1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class String1
{
    public static void f1(){
        String greeting = "Hello, World!";
        int n = greeting.length();
        System.out.println("Strinng greeting has length " + n);
    }
}
