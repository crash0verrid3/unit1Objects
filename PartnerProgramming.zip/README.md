# Unit 1: Objects

*Standard 2 - Understand and construct simple computer programs*

Practice programming activities and summative labs for Unit 1 (Chapters 1-2).
