
/**
 * Write a description of class TestingStuff here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestingStuff
{
    // instance variables - replace the example below with your own
    public static void $(){
        double $$ = 6^2;
        System.out.println($$);
    }
}
